﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace CodeDemo
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            Employee_Context_1712426 context = new Employee_Context_1712426();

            //context.Employees.Add(new Employee_172426() {  Name = "Bhanu", DOB = DateTime.Now.AddYears(-3), Address = "mumbai" });

            //context.SaveChanges();
            //MessageBox.Show("1 Record added!");

            //string nName = "Mouni";
            //DateTime dob = DateTime.Now.AddYears(-3);
            //Employee_172426 employee = context.Employees.SingleOrDefault(e1 => e1.ID == ID);
            //employee.Name = nName;
            //employee.DOB = dob;
            ////context.SaveChanges();
            ////MessageBox.Show("1 Record updated!");
            int ID = 4;

            Employee_172426 employee = context.Employees.SingleOrDefault(e1 => e1.ID == ID);
            context.Employees.Remove(employee);
            context.SaveChanges();
            MessageBox.Show("1 record deleted!");

            dgEmployee.ItemsSource = context.Employees.ToList();
            //var query = from ins in context.Employees
            //            where ins.price > 5000
            //            select ins;

            //context.Employees.Where(ins => ins.price > 5000);
        }
    }
}
