﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity;

namespace CodeDemo
{
    class Employee_Context_1712426 : DbContext
    {
       
    public Employee_Context_1712426():base("EmployeeCon")
    {

    }
        public DbSet<Employee_172426> Employees { get; set; }
    }
}
