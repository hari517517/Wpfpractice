﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity;

namespace codefirst_student_master
{
    class db_Student_Master:DbContext
    {
        public db_Student_Master():base("Trainings")
        {

        }
        public DbSet<Student_Master___172473> dbset { get; set; }
    }
}
