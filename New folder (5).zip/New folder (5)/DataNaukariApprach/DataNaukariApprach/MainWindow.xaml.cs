﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataNaukariApprach
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        Naukri_Entity naukri_Entity = null;
        static string emailid;
        public MainWindow()
        {
            naukri_Entity = new Naukri_Entity();
            InitializeComponent();
           
        }

        private void BtnSearch_Click(object sender, RoutedEventArgs e)
        {
            emailid = txtemailid.Text;
          
            var search = from p in naukri_Entity.Naukri_172477 where p.EmailId == emailid select p;
            naukri_Entity.SaveChanges();
            dgnaukri.DataContext = search.ToList();

           
        }

        private void Btndelete_Click(object sender, RoutedEventArgs e)
        {
            emailid = txtemailid.Text;
            var delete = (from delete1 in naukri_Entity.Naukri_172477 where delete1.EmailId == emailid select delete1).SingleOrDefault();
            naukri_Entity.Naukri_172477.Remove(delete);
            dgnaukri.ItemsSource = delete.ToString();

            MessageBox.Show("record deleted");
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            var original = from original1 in naukri_Entity.Naukri_172477 select original1;
            naukri_Entity.SaveChanges();
            dgorinal.DataContext = original.ToList();

        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {

            //emailid = txtemailid.Text;
            //Naukri_172477 naukri_172477 = new Naukri_172477();
            //naukri_Entity.Naukri_172477.Add(new Naukri_172477 { FullName = "sivagopikrishna", EmailId = "sivagopi255@gmail.com", MobileNumber = "8184968847", Gender = "male", Skills = "java", State = "telanaga", City = "hyd" });
            //naukri_Entity.SaveChanges();
            //dgnaukri.DataContext = naukri_Entity.Naukri_172477.ToList();

            //MessageBox.Show("record addred");
            var query=from s in naukri_Entity.Naukri_172477 select 
        }
    }
}
